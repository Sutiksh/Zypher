import 'package:flutter/material.dart';
import 'zypher.dart';
import 'qr_code_scanner.dart';


class Orders extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.all(0.0),
          children: <Widget>[
            DrawerHeader(
              child: Center(child: Text("Drawer Header")),
              decoration: BoxDecoration(color: Colors.blue),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ListTile(
                leading: Image.asset(
                  "qr_code.png",
                  width: 30,
                  height: 30,
                ),
                title: Text("Scan QR Code"),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Scan()),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ListTile(
                leading: Image.asset(
                  "your_order.png",
                  width: 30,
                  height: 30,
                ),
                title: Text("Your Orders"),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Orders()),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      appBar: AppBar(
        leading: GestureDetector(
          onTap: (){
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Zypher()),
            );
          },
          child: Icon(Icons.arrow_back),
        ),
        title: Text("Your Orders"),
        centerTitle: true,
      ),
    );
  }
}
