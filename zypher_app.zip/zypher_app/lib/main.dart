import 'package:flutter/material.dart';
import 'zypher.dart';

void main() async {
  runApp(
    new MaterialApp(
      title: 'Zypher',
      home: new Zypher(),
    ),
  );
}

